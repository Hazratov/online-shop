import 'package:flutter/material.dart';
import 'main.dart';

class AdminPanel extends StatelessWidget {
  final TextEditingController _imageUrlController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Panel'),
        // Orqaga qaytish tugmasi
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            // Avvalgi sahifaga qaytish
            Navigator.of(context).pop();
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Welcome to the Admin Panel!'),
            const SizedBox(height: 20),
            TextFormField(
              controller: _imageUrlController,
              decoration: const InputDecoration(labelText: 'Image URL'),
            ),
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            TextFormField(
              controller: _priceController,
              decoration: const InputDecoration(labelText: 'Price'),
              keyboardType: TextInputType.number,
            ),
            TextFormField(
              controller: _descriptionController,
              decoration: const InputDecoration(labelText: 'Description'),
              maxLines: 3,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Validate and add product
                final String imageUrl = _imageUrlController.text;
                final String name = _nameController.text;
                final double price = double.tryParse(_priceController.text) ?? 0.0;
                final String description = _descriptionController.text;

                // Validate inputs
                if (imageUrl.isNotEmpty && name.isNotEmpty && price > 0 && description.isNotEmpty) {
                  // Create product object and add it to exampleProducts list
                  Product newProduct = Product(image: imageUrl, name: name, price: price, description: description);
                  exampleProducts.add(newProduct); // Add new product to exampleProducts list

                  // Show success message or perform any other actions
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text('Product added successfully!'),
                  ));
                } else {
                  // Show error message or handle invalid input
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text('Please fill in all fields correctly!'),
                  ));
                }
              },
              child: const Text('Add Product'),
            ),
          ],
        ),
      ),
    );
  }
}

class Product {
  int id; // Avto-increment qilingan id
  final String image;
  final String name;
  final double price;
  final String description;

  Product({
    this.id = 0, // Boshlang'ich qiymat 0 bo'lishi kerak
    required this.image,
    required this.name,
    required this.price,
    required this.description,
  });

  // Fabrikator funksiya (named constructor) id yaratish uchun
  Product.withId({
    required this.id,
    required this.image,
    required this.name,
    required this.price,
    required this.description,
  });

  // Json obyektni Product obyektiga o'zgartirish
  factory Product.fromJson(Map<String, dynamic> json) => Product.withId(
    id: json['id'],
    image: json['image'],
    name: json['name'],
    price: json['price'],
    description: json['description'],
  );

  // Product obyektini Json obyektga o'zgartirish
  Map<String, dynamic> toJson() => {
    'id': id,
    'image': image,
    'name': name,
    'price': price,
    'description': description,
  };
}

// Example Product Objects
final List<Product> exampleProducts = [
  Product(
    image:
    'https://cdn.thewirecutter.com/wp-content/media/2023/05/running-shoes-2048px-9718.jpg',
    name: 'Comfortable Shoes',
    price: 59.99,
    description: 'Comfortable and stylish shoes for everyday wear.',
  ),
  Product(
    image:
    'https://billbird.co.uk/wp-content/uploads/2023/09/Bill-Bird-Shoes-Bespoke-Orthopaedic-Shoemakers-1.jpg',
    name: 'Running Shoes',
    price: 79.99,
    description: 'Lightweight and durable running shoes for athletes.',
  ),
];
