import 'package:flutter/material.dart';
import 'adminPanel.dart'; // adminPanel.dart faylini import qilamiz

void main() => runApp(const BottomNavigationBarExampleApp());

class BottomNavigationBarExampleApp extends StatelessWidget {
  const BottomNavigationBarExampleApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: BottomNavigationBarExample(),
    );
  }
}

class BottomNavigationBarExample extends StatefulWidget {
  const BottomNavigationBarExample({Key? key}) : super(key: key);

  @override
  State<BottomNavigationBarExample> createState() =>
      _BottomNavigationBarExampleState();
}

class _BottomNavigationBarExampleState
    extends State<BottomNavigationBarExample> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              decoration: const BoxDecoration(
                border: Border(
                  left: BorderSide(
                    color: Color.fromRGBO(19, 26, 41, 0.48),
                    width: 1,
                  ),
                ),
              ),
              child: IconButton(
                onPressed: () {
                  // Handle Filliallar button tap
                },
                icon: const Icon(Icons.chevron_left),
              ),
            ),
            Expanded(
              child: Center(
                child: Text(
                  'Online Shop',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ),
            ),
            Container(
              decoration: const BoxDecoration(
                border: Border(
                  right: BorderSide(
                    color: Color.fromRGBO(19, 26, 41, 0.48),
                    width: 1,
                  ),
                ),
              ),
              child: IconButton(
                onPressed: () {
                  // Handle ellipsis-horizontal button tap
                },
                icon: const Icon(Icons.more_horiz),
              ),
            ),
          ],
        ),
      ),
      body: _selectedIndex == 1
          ? ProfilePage()
          : Padding(
        padding: const EdgeInsets.fromLTRB(20, 30, 20, 30),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Categories',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildCategoryCard('Casual shoes'),
                  _buildCategoryCard('Loafer'),
                  _buildCategoryCard('Flats'),
                  _buildCategoryCard('Sneakers'),
                  _buildCategoryCard('Boat shoes'),
                  _buildCategoryCard('Oxford shoe'),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Container(
              width: double.infinity,
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      height: 50,
                      child: TextField(
                        decoration: InputDecoration(
                          hintText: 'Search',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  IconButton(
                    onPressed: () {
                      // Handle search button tap
                    },
                    icon: const Icon(Icons.search),
                    iconSize: 30,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            // Displaying Example Product Information
            Expanded(
              child: ListView.builder(
                itemCount: exampleProducts.length,
                itemBuilder: (BuildContext context, int index) {
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 10),
                    child: SizedBox(
                      width: double.infinity,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: double.infinity,
                              height: 200,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.network(
                                  exampleProducts[index].image,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              exampleProducts[index].name,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            Text(
                              '\$${exampleProducts[index].price.toString()}',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.green,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              exampleProducts[index].description,
                              style: const TextStyle(fontSize: 14),
                            ),
                            const SizedBox(height: 8),
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton(
                                onPressed: () {
                                  // Handle Buy button tap
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.blue, // Buy tugmasi fon rangi Blue
                                  padding: EdgeInsets.all(16), // qimmatli orqaga Buy tugmasi hajmi
                                  minimumSize: Size(double.infinity, 0), // Enter tugmasi eni 100%
                                ),
                                child: const Text(
                                  'BUY',
                                  style: TextStyle(color: Colors.white), // Matnning foni oq rang
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.login),
            label: 'Login',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: (int index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
    );
  }

  Widget _buildCategoryCard(String category) {
    return Container(
      margin: const EdgeInsets.only(right: 10),
      padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 15),
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Center(
        child: Text(
          category,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  // Foydalanuvchi tomonidan kiritilgan username va password
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  // Admin panelga kirishni tekshirish uchun funksiya
  void _checkCredentials(BuildContext context) {
    // Kiritilgan ma'lumotlar
    String enteredUsername = _usernameController.text.trim();
    String enteredPassword = _passwordController.text.trim();

    // Tekshirish
    if (enteredUsername == 'admin' && enteredPassword == 'admin123') {
      // Agar ma'lumotlar to'g'ri bo'lsa, admin panel ochiladi
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => AdminPanel()),
      );
    } else {
      // Aks holda, foydalanuvchiga xabar chiqariladi
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Authentication Failed'),
          content: Text('Incorrect username or password. Please try again.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('OK'),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(
                hintText: 'Username',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: InputDecoration(
                hintText: 'Password',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                _checkCredentials(context);
              },
              child: const Text(
                  'Enter',
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue, // Enter tugmasi fon rangi Blue
                padding: EdgeInsets.all(16), // qimmatli orqaga Enter tugmasi hajmi
                minimumSize: Size(double.infinity, 0), // Enter tugmasi eni 100%
              ),
            ),
          ],
        ),
      ),
    );
  }
}
