
class ProductModule {
  int? id;
  String? image;
  String? name;
  double? price;
  String? description;

  ProductModule({
    this.id,
    this.image,
    this.name,
    this.price,
    this.description,
  });

  factory ProductModule.fromJson(Map<String, dynamic> json) => ProductModule(
    id: json["id"],
    image: json["image"],
    name: json["name"],
    price: json["price"].toDouble(),
    description: json["description"],
  );

}
